/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


/**
 *
 * @author ACER
 */
public class koneksi {
    private String databaseName="2010010524";
    private String username="root";
    private String password="";
    private String lokasi="jdbc:mysql://localhost/"+databaseName;
    public static Connection koneksiDB;  
    
    // KONEKSI DATABASE
    public koneksi(){
        try {
           Class.forName("com.mysql.cj.jdbc.Driver") ;
           koneksiDB=DriverManager.getConnection(lokasi,username,password);
           System.out.println("database terkoneksi");
           
        } catch (Exception e) {
           System.err.println(e.toString()); 
        }
    }
    
    public void simpanKeluar(int idkeluar, int idbarang, String tanggal, int jumlah_keluar, String tujuan) {
        try {
            String SQL = "INSERT INTO keluar(idkeluar, idbarang, tanggal, jumlah_keluar, tujuan) VALUES(?,?,?,?,?)";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idkeluar);
            perintah.setInt(2, idbarang);
            perintah.setString(3, tanggal);
            perintah.setInt(4, jumlah_keluar);
            perintah.setString(5, tujuan);

            perintah.executeUpdate();
            System.out.println("Data keluar berhasil disimpan");

        } catch (Exception e) {
            System.out.println("Gagal menyimpan data keluar: " + e.getMessage());
        }
    }

    public void ubahKeluar(int idkeluar, int idbarang, String tanggal, int jumlah_keluar, String tujuan) {
        try {
            String SQL = "UPDATE keluar SET idbarang=?, tanggal=?, jumlah_keluar=?, tujuan=? WHERE idkeluar=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idbarang);
            perintah.setString(2, tanggal);
            perintah.setInt(3, jumlah_keluar);
            perintah.setString(4, tujuan);
            perintah.setInt(5, idkeluar);

            perintah.executeUpdate();
            System.out.println("Data keluar berhasil diubah");

        } catch (Exception e) {
            System.out.println("Gagal mengubah data keluar: " + e.getMessage());
        }
    }

    public void hapusKeluar(int idkeluar) {
        try {
            String SQL = "DELETE FROM keluar WHERE idkeluar=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idkeluar);

            perintah.executeUpdate();
            System.out.println("Data keluar berhasil dihapus");

        } catch (Exception e) {
            System.out.println("Gagal menghapus data keluar: " + e.getMessage());
        }
    }

    public void cariKeluar(int idkeluar) {
        try {
            String SQL = "SELECT * FROM keluar WHERE idkeluar=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);
            perintah.setInt(1, idkeluar);
            ResultSet data = perintah.executeQuery();

            while (data.next()) {
                System.out.println("ID Keluar        : " + data.getInt("idkeluar"));
                System.out.println("ID Barang        : " + data.getInt("idbarang"));
                System.out.println("Tanggal          : " + data.getString("tanggal"));
                System.out.println("Jumlah Keluar    : " + data.getInt("jumlah_keluar"));
                System.out.println("Tujuan           : " + data.getString("tujuan"));
            }

        } catch (Exception e) {
            System.err.println("Gagal mencari data keluar: " + e.getMessage());
        }
    }

    public void dataKeluar() {
        try {
            Statement stmt = koneksiDB.createStatement();
            ResultSet baris = stmt.executeQuery("SELECT * FROM keluar ORDER BY idkeluar ASC");

            System.out.println("ID Keluar | ID Barang | Tanggal | Jumlah Keluar | Tujuan");
            while (baris.next()) {
                System.out.println(baris.getInt("idkeluar") + " | "
                        + baris.getInt("idbarang") + " | "
                        + baris.getString("tanggal") + " | "
                        + baris.getInt("jumlah_keluar") + " | "
                        + baris.getString("tujuan"));
            }

        } catch (Exception e) {
            System.err.println("Gagal menampilkan data keluar: " + e.getMessage());
        }
    }
    
     public void simpanMasuk(int idmasuk, int idbarang, String tanggal, int jumlah_masuk) {
        try {
            String SQL = "INSERT INTO masuk(idmasuk, idbarang, tanggal, jumlah_masuk) VALUES(?,?,?,?)";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idmasuk);
            perintah.setInt(2, idbarang);
            perintah.setString(3, tanggal);
            perintah.setInt(4, jumlah_masuk);

            perintah.executeUpdate();
            System.out.println("Data masuk berhasil disimpan");

        } catch (Exception e) {
            System.out.println("Gagal menyimpan data masuk: " + e.getMessage());
        }
    }

    public void ubahMasuk(int idmasuk, int idbarang, String tanggal, int jumlah_masuk) {
        try {
            String SQL = "UPDATE masuk SET idbarang=?, tanggal=?, jumlah_masuk=? WHERE idmasuk=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idbarang);
            perintah.setString(2, tanggal);
            perintah.setInt(3, jumlah_masuk);
            perintah.setInt(4, idmasuk);

            perintah.executeUpdate();
            System.out.println("Data masuk berhasil diubah");

        } catch (Exception e) {
            System.out.println("Gagal mengubah data masuk: " + e.getMessage());
        }
    }

    public void hapusMasuk(int idmasuk) {
        try {
            String SQL = "DELETE FROM masuk WHERE idmasuk=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idmasuk);

            perintah.executeUpdate();
            System.out.println("Data masuk berhasil dihapus");

        } catch (Exception e) {
            System.out.println("Gagal menghapus data masuk: " + e.getMessage());
        }
    }

    public void cariMasuk(int idmasuk) {
        try {
            String SQL = "SELECT * FROM masuk WHERE idmasuk=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);
            perintah.setInt(1, idmasuk);
            ResultSet data = perintah.executeQuery();

            while (data.next()) {
                System.out.println("ID Masuk         : " + data.getInt("idmasuk"));
                System.out.println("ID Barang        : " + data.getInt("idbarang"));
                System.out.println("Tanggal          : " + data.getString("tanggal"));
                System.out.println("Jumlah Masuk     : " + data.getInt("jumlah_masuk"));
            }

        } catch (Exception e) {
            System.err.println("Gagal mencari data masuk: " + e.getMessage());
        }
    }

    public void dataMasuk() {
        try {
            Statement stmt = koneksiDB.createStatement();
            ResultSet baris = stmt.executeQuery("SELECT * FROM masuk ORDER BY idmasuk ASC");

            System.out.println("ID Masuk | ID Barang | Tanggal | Jumlah Masuk");
            while (baris.next()) {
                System.out.println(baris.getInt("idmasuk") + " | "
                        + baris.getInt("idbarang") + " | "
                        + baris.getString("tanggal") + " | "
                        + baris.getInt("jumlah_masuk"));
            }

        } catch (Exception e) {
            System.err.println("Gagal menampilkan data masuk: " + e.getMessage());
        }
    }
    
    public void simpanPeminjaman(int idpeminjam, int idbarang, String nama, String tanggal, String instansi, String keterangan) {
        try {
            String SQL = "INSERT INTO peminjaman(idpeminjam, idbarang, nama, tanggal, instansi, keterangan) VALUES(?,?,?,?,?,?)";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idpeminjam);
            perintah.setInt(2, idbarang);
            perintah.setString(3, nama);
            perintah.setString(4, tanggal);
            perintah.setString(5, instansi);
            perintah.setString(6, keterangan);

            perintah.executeUpdate();
            System.out.println("Data peminjaman berhasil disimpan");

        } catch (Exception e) {
            System.out.println("Gagal menyimpan data peminjaman: " + e.getMessage());
        }
    }

    public void ubahPeminjaman(int idpeminjaman, int idbarang, String nama, String tanggal, String instansi, String keterangan) {
        try {
            String SQL = "UPDATE peminjaman SET idbarang=?, nama=?, tanggal=?, instansi=?, keterangan=? WHERE idpeminjaman=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idbarang);
            perintah.setString(2, nama);
            perintah.setString(3, tanggal);
            perintah.setString(4, instansi);
            perintah.setString(5, keterangan);
            perintah.setInt(6, idpeminjaman);

            int hasil = perintah.executeUpdate();
            if (hasil > 0) {
                System.out.println("Data peminjaman dengan ID " + idpeminjaman + " berhasil diubah");
            } else {
                System.out.println("Data peminjaman dengan ID " + idpeminjaman + " tidak ditemukan");
            }

        } catch (Exception e) {
            System.out.println("Gagal mengubah data peminjaman: " + e.getMessage());
        }
    }

    public void hapusPeminjaman(int idpeminjaman) {
        try {
            String SQL = "DELETE FROM peminjaman WHERE idpeminjaman=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idpeminjaman);

            int hasil = perintah.executeUpdate();
            if (hasil > 0) {
                System.out.println("Data peminjaman dengan ID " + idpeminjaman + " berhasil dihapus");
            } else {
                System.out.println("Data peminjaman dengan ID " + idpeminjaman + " tidak ditemukan");
            }

        } catch (Exception e) {
            System.out.println("Gagal menghapus data peminjaman: " + e.getMessage());
        }
    }

    public void cariPeminjaman(int idpeminjaman) {
        try {
            String SQL = "SELECT * FROM peminjaman WHERE idpeminjaman=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);
            perintah.setInt(1, idpeminjaman);

            ResultSet data = perintah.executeQuery();

            while (data.next()) {
                System.out.println("ID Peminjaman: " + data.getInt("idpeminjaman"));
                System.out.println("ID Barang: " + data.getInt("idbarang"));
                System.out.println("Nama: " + data.getString("nama"));
                System.out.println("Tanggal: " + data.getString("tanggal"));
                System.out.println("Instansi: " + data.getString("instansi"));
                System.out.println("Keterangan: " + data.getString("keterangan"));
                System.out.println("----------------------------------");
            }

        } catch (Exception e) {
            System.out.println("Gagal mencari data peminjaman: " + e.getMessage());
        }
    }

    public void dataPeminjaman() {
        try {
            Statement stmt = koneksiDB.createStatement();
            ResultSet baris = stmt.executeQuery("SELECT * FROM peminjaman ORDER BY idpeminjaman ASC");

            System.out.println("ID Peminjaman | ID Barang | Nama | Tanggal | Instansi | Keterangan");
            while (baris.next()) {
                System.out.println(baris.getInt("idpeminjaman") + " | "
                        + baris.getInt("idbarang") + " | "
                        + baris.getString("nama") + " | "
                        + baris.getString("tanggal") + " | "
                        + baris.getString("instansi") + " | "
                        + baris.getString("keterangan"));
            }

        } catch (Exception e) {
            System.out.println("Gagal menampilkan data peminjaman: " + e.getMessage());
        }
    }
    
    public void simpanPengembalian(int idpengembali, int idbarang, String nama, String tanggal_kembali, String instansi) {
        try {
            String SQL = "INSERT INTO pengembalian(idpengembali, idbarang, nama, tanggal_kembali, instansi) VALUES(?,?,?,?,?)";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idpengembali);
            perintah.setInt(2, idbarang);
            perintah.setString(3, nama);
            perintah.setString(4, tanggal_kembali);
            perintah.setString(5, instansi);

            perintah.executeUpdate();
            System.out.println("Data pengembalian berhasil disimpan");

        } catch (Exception e) {
            System.out.println("Gagal menyimpan data pengembalian: " + e.getMessage());
        }
    }

    public void ubahPengembalian(int idpengembali, int idbarang, String nama, String tanggal_kembali, String instansi) {
        try {
            String SQL = "UPDATE pengembalian SET idbarang=?, nama=?, tanggal_kembali=?, instansi=? WHERE idpengembali=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idbarang);
            perintah.setString(2, nama);
            perintah.setString(3, tanggal_kembali);
            perintah.setString(4, instansi);
            perintah.setInt(5, idpengembali);

            int hasil = perintah.executeUpdate();
            if (hasil > 0) {
                System.out.println("Data pengembalian dengan ID " + idpengembali + " berhasil diubah");
            } else {
                System.out.println("Data pengembalian dengan ID " + idpengembali + " tidak ditemukan");
            }

        } catch (Exception e) {
            System.out.println("Gagal mengubah data pengembalian: " + e.getMessage());
        }
    }

    public void hapusPengembalian(int idpengembali) {
        try {
            String SQL = "DELETE FROM pengembalian WHERE idpengembali=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);

            perintah.setInt(1, idpengembali);

            int hasil = perintah.executeUpdate();
            if (hasil > 0) {
                System.out.println("Data pengembalian dengan ID " + idpengembali + " berhasil dihapus");
            } else {
                System.out.println("Data pengembalian dengan ID " + idpengembali + " tidak ditemukan");
            }

        } catch (Exception e) {
            System.out.println("Gagal menghapus data pengembalian: " + e.getMessage());
        }
    }

    public void cariPengembalian(int idpengembali) {
        try {
            String SQL = "SELECT * FROM pengembalian WHERE idpengembali=?";
            PreparedStatement perintah = koneksiDB.prepareStatement(SQL);
            perintah.setInt(1, idpengembali);

            ResultSet data = perintah.executeQuery();

            while (data.next()) {
                System.out.println("ID Pengembalian: " + data.getInt("idpengembali"));
                System.out.println("ID Barang: " + data.getInt("idbarang"));
                System.out.println("Nama: " + data.getString("nama"));
                System.out.println("Tanggal Kembali: " + data.getString("tanggal_kembali"));
                System.out.println("Instansi: " + data.getString("instansi"));
                System.out.println("----------------------------------");
            }

        } catch (Exception e) {
            System.out.println("Gagal mencari data pengembalian: " + e.getMessage());
        }
    }

    public void dataPengembalian() {
        try {
            Statement stmt = koneksiDB.createStatement();
            ResultSet baris = stmt.executeQuery("SELECT * FROM pengembalian ORDER BY idpengembali ASC");

            System.out.println("ID Pengembalian | ID Barang | Nama | Tanggal Kembali | Instansi");
            while (baris.next()) {
                System.out.println(baris.getInt("idpengembali") + " | "
                        + baris.getInt("idbarang") + " | "
                        + baris.getString("nama") + " | "
                        + baris.getString("tanggal_kembali") + " | "
                        + baris.getString("instansi"));
            }

        } catch (Exception e) {
            System.out.println("Gagal menampilkan data pengembalian: " + e.getMessage());
        }
    }
}
