/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package barang;

/**
 *
 * @author ACER
 */
public class peminjaman {
    String idbarang, keterangan, jumlah_barang, instansi, tanggal, nama;

    public peminjaman() {} // constructor

    public void inputIdbarang(String idbarang) {
        this.idbarang = idbarang;
    }

    public String ambilIdbarang() {
        return this.idbarang;
    }

    public void inputNama(String nama) {
        this.nama = nama;
    }

    public String ambilNama() {
        return this.nama;
    }

    public void inputTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String ambilTanggal() {
        return this.tanggal;
    }

    public void inputInstansi(String instansi) {
        this.instansi = instansi;
    }

    public String ambilInstansi() {
        return this.instansi;
    }

    public void inputJumlah_barang(String jumlah_barang) {
        this.jumlah_barang = jumlah_barang;
    }

    public String ambilJumlah_barang() {
        return this.jumlah_barang;
    }

    public void inputKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String ambilKeterangan() {
        return this.keterangan;
    }
}
