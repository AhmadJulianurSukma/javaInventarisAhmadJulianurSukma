/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package barang;

/**
 *
 * @author ACER
 */
public class masuk {
    String idbarang, jumlah_masuk, tanggal;

    public masuk() {} // constructor

    // Method untuk mengambil data dari objek peminjaman
    public void ambilDataDariPeminjaman(peminjaman pinjam) {
        this.idbarang = pinjam.ambilIdbarang();
        this.tanggal = pinjam.ambilTanggal();
        this.jumlah_masuk = pinjam.ambilJumlah_barang();
    }

    public String ambilIdbarang() {
        return this.idbarang;
    }

    public String ambilTanggal() {
        return this.tanggal;
    }

    public String ambilJumlah_masuk() {
        return this.jumlah_masuk;
    }
}
