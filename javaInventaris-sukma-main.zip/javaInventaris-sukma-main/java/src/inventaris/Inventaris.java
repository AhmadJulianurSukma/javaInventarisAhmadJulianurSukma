/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventaris;

import barang.*;
import java.util.Scanner;
import crud.koneksi;
import gui.*;
//import crud.koneksi;
//import gui.*;
/**
 *
 * @author ACER
 */
public class Inventaris {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new frameUtama().setVisible(true);
        
//        koneksi db = new koneksi();
//        db.simpanPengembalian(1, 1, "abdan", "2020", "perindo");
        
//        // TODO code application logic here
//        Scanner scanner = new Scanner(System.in);
//
//        // Input data peminjaman
//        System.out.println("=== Input Data Peminjaman ===");
//        System.out.print("Masukkan ID Barang: ");
//        String idbarang = scanner.nextLine();
//
//        System.out.print("Masukkan Nama Peminjam: ");
//        String nama = scanner.nextLine();
//
//        System.out.print("Masukkan Tanggal Peminjaman: ");
//        String tanggal = scanner.nextLine();
//
//        System.out.print("Masukkan Instansi: ");
//        String instansi = scanner.nextLine();
//
//        System.out.print("Masukkan Jumlah Barang Dipinjam: ");
//        String jumlah_barang = scanner.nextLine();
//
//        System.out.print("Masukkan Keterangan: ");
//        String keterangan = scanner.nextLine();
//
//        // Membuat objek peminjaman
//        peminjaman pinjam = new peminjaman();
//        pinjam.inputIdbarang(idbarang);
//        pinjam.inputNama(nama);
//        pinjam.inputTanggal(tanggal);
//        pinjam.inputInstansi(instansi);
//        pinjam.inputJumlah_barang(jumlah_barang);
//        pinjam.inputKeterangan(keterangan);
//
//        // Membuat objek masuk dan mengambil data dari peminjaman
//        masuk masukBarang = new masuk();
//        masukBarang.ambilDataDariPeminjaman(pinjam);
//
//        // Menampilkan hasil
//        System.out.println("\n=== Data Peminjaman Barang ===");
//        System.out.println("-------------------------------");
//        System.out.println("ID Barang            : " + masukBarang.ambilIdbarang());
//        System.out.println("Nama Peminjam        : " + pinjam.ambilNama());
//        System.out.println("Tanggal              : " + masukBarang.ambilTanggal());
//        System.out.println("Instansi             : " + pinjam.ambilInstansi());
//        System.out.println("Jumlah Barang Dipinjam: " + pinjam.ambilJumlah_barang());
//        System.out.println("Keterangan           : " + pinjam.ambilKeterangan());
//        System.out.println("-------------------------------");
//
//        scanner.close();
    }
    
}
